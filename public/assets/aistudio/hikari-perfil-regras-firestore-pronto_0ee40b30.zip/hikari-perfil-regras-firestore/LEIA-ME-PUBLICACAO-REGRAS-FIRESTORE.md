# Publicação controlada das regras do Firestore — Hikari Perfil

Este pacote preserva o código original recebido e adiciona somente:

- `firebase.json`, apontando o Firebase CLI para `firestore.rules`;
- este guia de publicação.

O arquivo `firestore.rules` não foi alterado. Ele já contém as regras das conversas privadas e mensagens, além das regras de perfis, privacidade e demais áreas do projeto.

## Atenção antes de publicar

O conteúdo de regras que foi copiado do Console Firebase e enviado na conversa não continha os blocos `/conversations/{convId}` e `/messages/{msgId}`. Isso explica o `permission-denied` se aquele conteúdo era realmente a versão integral publicada.

Este pacote **não publica nada automaticamente** e não contém `.firebaserc` para evitar fixar silenciosamente um projeto Firebase.

## 1. Validar o projeto selecionado

No terminal, na pasta raiz deste projeto:

```bash
firebase projects:list
```

Confirme que `hikari-user-profiles` é o projeto correto.

## 2. Validar as regras antes de publicar

Use o Firebase CLI para verificar a configuração e a sintaxe. Para uma validação de comportamento, execute também testes com o Firestore Emulator e Firebase Rules Unit Testing. Não considere testes mockados de `chatService.ts` como validação das regras reais.

## 3. Publicar somente as regras do Firestore (ação manual e explícita)

Somente depois de revisar `firestore.rules`, confirmar o projeto e aprovar a publicação:

```bash
firebase deploy --only firestore:rules --project hikari-user-profiles
```

Esse comando publica apenas as regras do Firestore; não publica o site na Vercel.

## 4. Teste após a publicação

Com duas contas reais e distintas:

1. A conta A inicia uma conversa nova com a conta B e envia uma mensagem.
2. Confirme no Firestore que o documento pai e a mensagem foram criados.
3. A conta B abre a conversa e recebe a mensagem.
4. Atualize as duas sessões e confirme que o histórico permanece.
5. Teste que uma terceira conta não participante não consegue ler a conversa.

Se qualquer etapa falhar, registre o erro completo do Firebase e interrompa novos envios de mensagens até investigar.

## Limitações desta entrega

- Nenhuma regra foi publicada no Firebase.
- Nenhum deploy foi feito na Vercel.
- Nenhum arquivo de aplicação ou `chatService.ts` foi alterado.
- Não foi possível comprovar, a partir do ZIP, que as regras locais já foram publicadas ou que passaram pelo compilador/emulador do Firebase.
